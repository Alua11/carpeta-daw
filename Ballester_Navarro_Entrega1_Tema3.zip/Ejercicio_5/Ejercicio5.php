<?php
$vendProd = [
    "vendedor1" => [
        "Monitores" => 50, "Ratones" => 123, "Teclados" => 321, "Alfombrillas" => 122, "Micros" => 904, "Mandos" => 723, "Cascos" => 234, "Camaras" => 53, "Hdmi" => 323, "Routers" => 234
    ],
    "vendedor2" => [
        "Monitores" => 36, "Ratones" => 758, "Teclados" => 324, "Alfombrillas" => 312, "Micros" => 690, "Mandos" => 323, "Cascos" => 434, "Camaras" => 853, "Hdmi" => 333, "Routers" => 534
    ],
    "vendedor3" => [
        "Monitores" => 654, "Ratones" => 566, "Teclados" => 564, "Alfombrillas" => 789, "Micros" => 987, "Mandos" => 123, "Cascos" => 321, "Camaras" => 417, "Hdmi" => 963, "Routers" => 548
    ],
    "vendedor4" => [
        "Monitores" => 545, "Ratones" => 58, "Teclados" => 321, "Alfombrillas" => 137, "Micros" => 901, "Mandos" => 723, "Cascos" => 235, "Camaras" => 545, "Hdmi" => 324, "Routers" => 245
    ],
    "vendedor5" => [
        "Monitores" => 123, "Ratones" => 288, "Teclados" => 322, "Alfombrillas" => 136, "Micros" => 902, "Mandos" => 736, "Cascos" => 235, "Camaras" => 544, "Hdmi" => 325, "Routers" => 244
    ],
    "vendedor6" => [
        "Monitores" => 56, "Ratones" => 899, "Teclados" => 323, "Alfombrillas" => 135, "Micros" => 903, "Mandos" => 737, "Cascos" => 237, "Camaras" => 543, "Hdmi" => 326, "Routers" => 243
    ],
    "vendedor7" => [
        "Monitores" => 867, "Ratones" => 456, "Teclados" => 324, "Alfombrillas" => 134, "Micros" => 904, "Mandos" => 735, "Cascos" => 236, "Camaras" => 542, "Hdmi" => 327, "Routers" => 242
    ],
    "vendedor8" => [
        "Monitores" => 534, "Ratones" => 456, "Teclados" => 325, "Alfombrillas" => 132, "Micros" => 905, "Mandos" => 734, "Cascos" => 238, "Camaras" => 541, "Hdmi" => 328, "Routers" => 240
    ],
    "vendedor9" => [
        "Monitores" => 879, "Ratones" => 254, "Teclados" => 326, "Alfombrillas" => 131, "Micros" => 906, "Mandos" => 733, "Cascos" => 239, "Camaras" => 540, "Hdmi" => 329, "Routers" => 241
    ],
    "vendedor10" => [
        "Monitores" => 856, "Ratones" => 25, "Teclados" => 327, "Alfombrillas" => 129, "Micros" => 907, "Mandos" => 732, "Cascos" => 244, "Camaras" => 539, "Hdmi" => 330, "Routers" => 239
    ],
    "vendedor11" => [
        "Monitores" => 123, "Ratones" => 25, "Teclados" => 328, "Alfombrillas" => 128, "Micros" => 908, "Mandos" => 731, "Cascos" => 241, "Camaras" => 537, "Hdmi" => 331, "Routers" => 238
    ],
    "vendedor12" => [
        "Monitores" => 345, "Ratones" => 25, "Teclados" => 329, "Alfombrillas" => 127, "Micros" => 909, "Mandos" => 730, "Cascos" => 242, "Camaras" => 538, "Hdmi" => 332, "Routers" => 2347
    ],
    "vendedor13" => [
        "Monitores" => 657, "Ratones" => 25, "Teclados" => 331, "Alfombrillas" => 126, "Micros" => 910, "Mandos" => 729, "Cascos" => 246, "Camaras" => 536, "Hdmi" => 333, "Routers" => 236
    ],
    "vendedor14" => [
        "Monitores" => 125, "Ratones" => 25, "Teclados" => 332, "Alfombrillas" => 125, "Micros" => 911, "Mandos" => 728, "Cascos" => 247, "Camaras" => 535, "Hdmi" => 334, "Routers" => 235
    ],
    "vendedor15" => [
        "Monitores" => 50, "Ratones" => 25, "Teclados" => 333, "Alfombrillas" => 124, "Micros" => 912, "Mandos" => 727, "Cascos" => 248, "Camaras" => 534, "Hdmi" => 335, "Routers" => 250
    ],
    "vendedor16" => [
        "Monitores" => 50, "Ratones" => 25, "Teclados" => 334, "Alfombrillas" => 123, "Micros" => 913, "Mandos" => 726, "Cascos" => 249, "Camaras" => 533, "Hdmi" => 336, "Routers" => 233
    ],
    "vendedor17" => [
        "Monitores" => 50, "Ratones" => 25, "Teclados" => 344, "Alfombrillas" => 122, "Micros" => 914, "Mandos" => 725, "Cascos" => 259, "Camaras" => 532, "Hdmi" => 337, "Routers" => 232
    ],
    "vendedor18" => [
        "Monitores" => 50, "Ratones" => 25, "Teclados" => 356, "Alfombrillas" => 121, "Micros" => 915, "Mandos" => 724, "Cascos" => 263, "Camaras" => 531, "Hdmi" => 338, "Routers" => 231
    ],

];
$cadenaJson = json_encode($vendProd, JSON_OBJECT_AS_ARRAY);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="inicio.php" method="post">
        Gestion de ventas:
        <input type="submit" id="comenzar" name="comenzar" value="Comenzar">
        <input type="hidden" id="cadenaArray" name="cadenaArray" value=<?= $cadenaJson ?>>

    </form>

</body>

</html>