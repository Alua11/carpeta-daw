<?php

$cadenaJson = $_REQUEST["cadenaArray"];
$arrayJson = [];
$arrayJson = json_decode($cadenaJson, JSON_OBJECT_AS_ARRAY);
$vendedorSol = false;



if (!isset($_REQUEST["vendedorsol"])) {
?>
    <form action="VerVendedor.php" method="post">
        Vendedor:<select name="vendedorsol" id="vendedorsol">
            <?php
            foreach ($arrayJson as $vendedor => $numero) {
                echo "<option>{$vendedor}</option>";
            }

            ?>
        </select>
        <br>
        <input type="hidden" name="cadenaArray" id="cadenaArray" value=<?= $cadenaJson ?>>

        <input type="submit" value="Escoja vendedor">
    </form>
<?php
} else {

    $vendedorSol = $_REQUEST["vendedorsol"];
    $cadena = "";
    function MostrarVendedor(array $trabajador, String $trabajadorElegido, String $cadena)
    {
        $total = 0;
        $cadena = "<table>";
        foreach ($trabajador as $indice => $numero) {
            if ($trabajadorElegido == $indice) {
                foreach ($numero as $objeto => $valor) {
                    $cadena .= "<tr><td>El {$trabajadorElegido} ha vendido {$valor} {$objeto}.</td></tr>";

                    $total += $valor;
                }
            }
        }
        $cadena .= "<tr><td>El {$trabajadorElegido} ha vendido {$total} de unidades.</td></tr>";
        $cadena .= "</table>";

        return $cadena;
    }

echo "El vendedor elegido es {$vendedorSol}";
    echo MostrarVendedor($arrayJson, $vendedorSol, $cadena);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php
    include_once("Menu.php");

    ?>
</body>

</html>