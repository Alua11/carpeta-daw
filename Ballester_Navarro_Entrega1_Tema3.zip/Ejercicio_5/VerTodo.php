<?php

$cadenaJson = $_REQUEST["cadenaArray"];
$arrayJson = [];
$arrayJson = json_decode($cadenaJson, JSON_OBJECT_AS_ARRAY);
$valor = false;
$cadena = "";
echo "El valor total de vendedores y productos:";
echo MostrarTodo($arrayJson, $cadena);


function MostrarTodo(array $trabajador, String $cadena)
{

    $total = 0;
    $cadena = "<table>";
    foreach ($trabajador as $indice => $numero) {
        foreach ($numero as $objeto => $valor) {
            $cadena .= "<tr><td>El {$indice}  ha vendido {$objeto}: {$valor} unidades.</td></tr>";
            $total += $valor;
        }
    }
    $cadena .= "<tr><td>El total de productos vendidos es de {$total} unidades.</td></tr>";
    $cadena .= "</table>";
    return $cadena;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    include_once("Menu.php");
    ?>
</body>

</html>