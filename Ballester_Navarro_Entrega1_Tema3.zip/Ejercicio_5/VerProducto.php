<?php
$cadenaJson = $_REQUEST["cadenaArray"];
$arrayJson = [];
$arrayJson = json_decode($cadenaJson, JSON_OBJECT_AS_ARRAY);
$producto = false;

if (!isset($_REQUEST["productomostrar"])) {
?>
    <form action="VerProducto.php" method="post">
        Producto:<select name="productomostrar" id="productomostrar">
            <?php
            foreach ($arrayJson as $producto => $nombre) {
            }
            foreach ($nombre as $nombreProducto => $objeto) {
                echo "<option>{$nombreProducto}</option>";
            }
            ?>
        </select>
        <br>
        <input type="hidden" name="cadenaArray" id="cadenaArray" value=<?= $cadenaJson ?>>
        <input type="submit" value="Escoja vendedor">
    </form>

<?php
} else {
    $cadena = "";
    $producto = $_REQUEST["productomostrar"];
    function MostrarProducto(array $trabajador, String $trabajadorElegido, String $cadena)
    {
        $total = 0;
        $cadena = "<table>";
        foreach ($trabajador as $indice => $numero) {
            foreach ($numero as $objeto => $valor) {
                if ($trabajadorElegido == $objeto) {

                    $cadena .= "<tr><td>El {$indice} ha vendido {$valor} {$objeto}.</td></tr>";
                    $total += $valor;
                }
            }
        }
        $cadena .= "<tr><td>El total de ventas de ha sido de  {$total} unidades.</td></tr>";
        $cadena .= "</table>";
        return $cadena;
    }
    echo "El producto elegido es {$producto}";
    echo MostrarProducto($arrayJson, $producto, $cadena);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php
    include_once("Menu.php");

    ?>
</body>

</html>