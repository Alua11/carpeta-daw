<?php

$cadenaJson = $_REQUEST["cadenaArray"];
$arrayJson = [];
$arrayJson = json_decode($cadenaJson, JSON_OBJECT_AS_ARRAY);
$valor = false;


if (!isset($_REQUEST["valor"])) {
?>
    <form action="ModificarProducto.php" method="post">
        Vendedor:<select name="modificar" id="modificar">
            <?php
            foreach ($arrayJson as $modificador => $objMod) {
                echo "<option>{$modificador}</option>";
            }


            ?>
        </select>
        <br>
        Producto:<select name="productomod" id="productomod">
            <?php
            foreach ($objMod as $productoMod => $objModificable) {
                echo "<option>{$productoMod}</option>";
            }
            ?>
        </select>
        <br>
        <input type="number" name="valor" id="valor" value="">
        <input type="hidden" id="cadenaArray" name="cadenaArray" value=<?= $cadenaJson ?>>

        <br>
        <input type="submit" value="Producto a Modificar">
    </form>
<?php
} else {

    $modifico = $_REQUEST["modificar"];
    $productomod = $_REQUEST["productomod"];
    $valor = $_REQUEST["valor"];
    echo "El valor de {$productomod} ha sido cambiado de  {$arrayJson[$modifico][$productomod]} a {$valor} unidades";
    $arrayJson[$modifico][$productomod] = $valor;


    $cadenaJson = json_encode($arrayJson, JSON_OBJECT_AS_ARRAY);
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php
    include_once("Menu.php");

    ?>
</body>

</html>