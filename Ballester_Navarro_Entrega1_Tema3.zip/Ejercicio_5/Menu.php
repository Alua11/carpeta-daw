     
     <form action="VerVendedor.php" method="post">
         Visualizar:<br>
         <input type="submit" id="vendedor" name="vendedor" value="Vendedor">
         <input type="hidden" id="cadenaArray" name="cadenaArray" value=<?= $cadenaJson ?>>
     </form>
     <form action="VerProducto.php" method="post">
         <input type="submit" id="producto" name="producto" value="Producto">
         <input type="hidden" id="cadenaArray" name="cadenaArray" value=<?= $cadenaJson ?>>
     </form>
     <form action="VerTodo.php" method="post">
         <input type="submit" id="todo" name="todo" value="Todo">
         <input type="hidden" id="cadenaArray" name="cadenaArray" value=<?= $cadenaJson ?>>
     </form>
     <br>
     <form action="ModificarProducto.php" method="post">
         Modificar Producto:
         <input type="submit" id="modProd" name="ModProd" value="Producto">
         <input type="hidden" id="cadenaArray" name="cadenaArray" value=<?= $cadenaJson ?>>
     </form>

