<?php
include_once("funciones.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form method="POST" action="Ejercicio3.php">
        Introduzca un numero valido entre 2 y 15: <input type="text" id="elegida" name="elegida" value="<?= $_REQUEST["elegida"] ?? "" ?>"><br>
        <input type="submit" id="boton" name="Enviar">

    </form>

    <?php

    if (isset($_REQUEST["elegida"])) {
        $datos = $_REQUEST["elegida"];
        if (!is_numeric($datos)) {
            echo "Debes introducir numeros.";
        } else if ($datos <= 1) {
            echo "El numero introducido debe ser mayor o igual a 2";
        } else {
            creaVelas($datos);
        }
    }




    ?>
</body>

</html>