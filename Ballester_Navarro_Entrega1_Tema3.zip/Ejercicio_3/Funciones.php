<?php


function creaVelas(int $datos)
{
    $datos = $_REQUEST["elegida"];


    for ($i = 1; $i <= $datos; $i++) {
        echo "&nbsp";
        for ($j = 1; $j <= ($datos - $i) + 1; $j++) {
            echo "&nbsp&nbsp";
        }

        $filas = $i;
        $cambiante = true;
        for ($x = 1; $x <= ($i * 2) - 1; $x++) {
            echo "{$filas}";
            if ($cambiante) {
                $filas--;
                if ($filas == 1) {
                    $cambiante = false;
                }
            } else {
                $filas++;
            }
        }
        for ($y = 1; $y <= ($datos - $i) + 1; $y++) {
            echo "&nbsp";
        }
        echo "<br>";
    }
}
