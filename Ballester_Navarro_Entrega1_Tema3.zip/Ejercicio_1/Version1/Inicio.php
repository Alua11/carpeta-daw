<form action="Funciones.php" method="post">
    <!-- Pedimos al usuarios los datos necesarios para comenzar el programa -->
    Introduzca su frase: <input type="text" name="texto" id="cifrar" value=""><br>
    Introduzca la semilla de forma numerica: <input type="text" name="semilla" id="semilla" value=""><br>

    <input type="submit" name="cifrar" id="cifrar" value="Cifrar">
    <input type="submit" name="descifrar" id="descifrar" value="Descifrar">
</form>
<?php
// Imprimimos los errores en caso de existir.
if (isset($_REQUEST["datos"])) {
    echo $_REQUEST["datos"];
}
