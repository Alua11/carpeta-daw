<?php
include_once("Inicio.php");
$letras = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];

// En esta recibe un array y un caracter y devuelve la posicion que ocupa este caracter en el array
function BuscaPosicion(array $letras, string $caracter)
{
    for ($i = 0; $i < count($letras); $i++) {
        if ($letras[$i] == $caracter) {
            return $i;
        }
    }
    // En caso de no encontrase el caracter devuelve 0
    return 0;
}

//En esta funcion recibimos el array, la frase del usuario y la semilla elegida por el mismo en formato string
function cifrar(array $letras, string $frase, String $semilla)
{
    //Declaracion de variables y preprocesado de datos
    $posicion = 0;
    $indiceSemilla = 0;
    $posicionSemilla = 0;
    $aux = "";
    $texto = strtolower(trim($frase));
    $semillaminus = strtolower(trim($semilla));
    $tamanyoLetra = count($letras);
    // En este bucle se recorre la frase introducida por el usuario como si fuera un array de caracteres para el cifrado individual de cada uno de los caracteres.
    for ($i = 0; $i < strlen($frase); $i++) {
        //Llamamos a la funcion BuscaPosicion para conocer a que posicion del array corresponde la letra.
        $posicion = BuscaPosicion($letras, $texto[$i]);
        //Llamamos a la funcion BuscaPosicion para conocer a que posicion del array corresponde el caracter actual de la semilla.
        $posicionSemilla = BuscaPosicion($letras, $semillaminus[$indiceSemilla]);
        //Si el texto tiene espacios se añaden a la cadena
        if ($texto[$i] == " ") {
            $aux .= " ";
            //Si el texto tiene numeros se añaden a la cadena
        } else if (is_numeric($texto[$i])) {
            $aux .= $texto[$i];
        } else {
            //La posicion del caracter cifrado corresponde a la posicion actual mas la posicion actual de la semilla +1(ya que el array comienza en 0).
            $NuevaPosicion = $posicion + $posicionSemilla + 1;
            // Para evitar que la nueva posicion exceda el array de caracteres usamos un modular.
            $mod = ($NuevaPosicion % $tamanyoLetra);
            $aux .= $letras[$mod];
        }

        //Sumamos 1 al indice de la semilla para tratar el siguiente caracter de la semilla salvo en caso de que el indice de la semilla exceda la longitud de la misma.
        //  en ese caso reseteamos el indice.
        $indiceSemilla++;
        if ($indiceSemilla >= strlen($semillaminus)) {
            $indiceSemilla = 0;
        }
    }


    return $aux;
}

function descifrar(array $letras, string $frase, String $semilla)
{
    //Declaracion de variables y preprocesado de datos
    $posicion = 0;
    $indiceSemilla = 0;
    $posicionSemilla = 0;
    $aux = "";
    $texto = strtolower(trim($frase));
    $semillaminus = strtolower(trim($semilla));
    $tamanyoLetra = count($letras);
    // En este bucle se recorre la frase introducida por el usuario como si fuera un array de caracteres para el cifrado individual de cada uno de los caracteres.
    for ($i = 0; $i < strlen($frase); $i++) {
        //Llamamos a la funcion BuscaPosicion para conocer a que posicion del array corresponde la letra.
        $posicion = BuscaPosicion($letras, $texto[$i]);
        //Llamamos a la funcion BuscaPosicion para conocer a que posicion del array corresponde el caracter actual de la semilla.
        $posicionSemilla = BuscaPosicion($letras, $semillaminus[$indiceSemilla]);
        //Si el texto tiene espacios se añaden a la cadena
        if ($texto[$i] == " ") {
            $aux .= " ";
            //Si el texto tiene numeros se añaden a la cadena
        } else if (is_numeric($texto[$i])) {
            $aux .= $texto[$i];
        } else {
            // La nueva posicion es la posicion desplazada hacia la izquierda por el valor de la posicion de la semilla +1(ya que empieza en 0 el array).
            $NuevaPosicion = $posicion - ($posicionSemilla + 1);
            // Si la nueva es mayor a 0 esto significa que corresponde a una posicion del array y la añadimos a nuestro auxiliar.
            if ($NuevaPosicion >= 0) {
                $aux .= $letras[$NuevaPosicion];
            }
            // En caso de ser menor a 0 la nueva posicion la obtenemos restando al valor maximo del array NuevaPosicion.
            else {

                $aux .= $letras[$tamanyoLetra + ($NuevaPosicion)];
            }
        }

        //Sumamos 1 al indice de la semilla para tratar el siguiente caracter de la semilla salvo en caso de que el indice de la semilla exceda la longitud de la misma.
        //  en ese caso reseteamos el indice.
        $indiceSemilla++;
        if ($indiceSemilla >= strlen($semillaminus)) {
            $indiceSemilla = 0;
        }
    }

    return $aux;
}





//comprobacion de que el texto no este vacio
if (empty($_REQUEST["texto"])) {
    $error = "No existe  texto";
    header("location:Inicio.php?datos=" . $error);
    exit;
}
// Comprobacion de que la semilla no este vacia y no sea numerica
if (empty($_REQUEST["semilla"]) || is_numeric($_REQUEST["semilla"])) {
    $error = "No existe semilla o es numerica";
    header("location:Inicio.php?datos=" . $error);
    exit;
}
// Comprobacion  del boton pulsado ya sea cifrar o descifrar.
if (isset($_REQUEST["cifrar"])) {
    $frase = $_REQUEST["texto"];
    $semilla = $_REQUEST["semilla"];

    echo cifrar($letras, $frase, $semilla);
} else {
    $frase = $_REQUEST["texto"];
    $semilla = $_REQUEST["semilla"];
    echo descifrar($letras, $frase, $semilla);
}
