<?php
require_once("funciones.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>

<body>
    Ejercicio 2 FECHA <br><br>

    - Solo acepta / como separador. <br>
    -No estan considerados los años bisiestos.<br>
    - Formato de fecha aceptados dd/mm/aaaa, d/m/aaaa. <br><br>
    <?php


    //caso inicial

    $fecha = "";

    if (!isset($_POST['fecha'])) {
        llamaFormulario($fecha);
    }

    //Segundo caso y final
    if (isset($_POST['fecha'])) {

        $fecha = $_POST['fecha'];

        if (strpos($fecha, "/")) {

            $fecha = $_POST['fecha'];

            $fechaFinal = ImprimeFecha($fecha);

            $dia = $fechaFinal[0];
            $mes = $fechaFinal[1];
            $anyo = $fechaFinal[2];

            $arrayDia = esValidodia($dia, $mes);
            $arrayMes = mes($mes);
            $arrayAnyo = anyo($anyo);

            if ($arrayDia["valido"] == false || $arrayMes["valido"] == false || $arrayAnyo["valido"] == false) {
                llamaFormulario($fecha);
                echo ($arrayDia["valido"] == false) ? "<p style= 'color:red'>{$arrayDia['Msg']}</style></p>" : "<p style= 'color:green'>{$arrayDia['Msg']}</style></p>";
                echo ($arrayMes["valido"] == false) ? "<p style= 'color:red'>{$arrayMes['Msg']}</style></p>" : "<p style= 'color:green'>{$arrayMes['Msg']}</style></p>";
                echo ($arrayAnyo["valido"] == false) ? "<p style= 'color:red'>{$arrayAnyo['Msg']}</style></p>" : "<p style= 'color:green'>{$arrayAnyo['Msg']}</style></p>";
            } else {

                echo "<p style= 'color:green'>{$arrayDia['Msg']}</style></p>";
                echo "<p style= 'color:green'>{$arrayMes['Msg']}</style></p>";
                echo "<p style= 'color:green'>{$arrayAnyo['Msg']}</style></p>";
                llamaFormulario($fecha);
            }
        } else {
            echo "<p style= 'color:red'>Formato de fecha no válido</style></p>";
        }
    }


    ?>
</body>

</html>