<?php
function llamaFormulario($fecha)
{

?>
    <form action="<?= $_SERVER['PHP_SELF'] ?>" method="POST">
        INTRODUCE FECHA : <input type="text" id="fecha" name="fecha" value="<?= $fecha ?>">


        <input type="submit" id="boton" name="boton">
    </form>
<?php
}

function ImprimeFecha(string $fecha): array
{

    $separador = "/";
    $fechaF = $fecha . $separador;
    $aux = [];
    $contador = 0;
    for ($i = 0; $i < strlen($fechaF); $i++) {

        $aux[$i] = substr($fechaF, 0, strpos($fechaF, "/"));
        $fechaF = substr($fechaF, strpos($fechaF, "/") + strlen($separador));
    }
    return $aux;
}




function esValidodia($dia, $mes)
{
    $arrayResultado = ["valido" => true, "Msg" => "Dia:  $dia Válido <br>"];
 
    if (is_numeric($dia) && $dia > 0) {
        switch ($mes) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                if ($dia > 31) {
                    $arrayResultado["valido"] = false;
                    $arrayResultado["Msg"] = "No puede haber más de 31 días <br>";
                    return $arrayResultado;
                }
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                if ($dia > 30) {
                    $arrayResultado["valido"] = false;
                    $arrayResultado["Msg"] = "Este mes no tiene tantos días <br>";
                }
                break;
            case 2:
                if ($dia > 28) {
                    $arrayResultado["valido"] = false;
                    $arrayResultado["Msg"] = "El mes de febrero no tiene tantos días <br>";
                }
                break;
            default:

                $arrayResultado["valido"] = false;
                $arrayResultado["Msg"] = "Dia correcto pero mes incorrecto <br>";
                return $arrayResultado;
        }
        return $arrayResultado;
    } else {
        $arrayResultado["valido"] = false;
        $arrayResultado["Msg"] = "Dia con formato incorrecto, solo números válidos del 1 al 31 <br>";
        return $arrayResultado;
    }
}

function mes($mes)
{
    $arrayResultado = ["valido" => true, "Msg" => "Mes:  $mes Válido <br>"];
    if (!is_numeric($mes) || $mes < 1 || $mes > 12) {
        $arrayResultado["valido"] = false;
        $arrayResultado["Msg"] = "Introduce un mes del 1 al 12 <br>";
    }
    return $arrayResultado;
}

function anyo($anyo)
{
    $arrayResultado = ["valido" => true, "Msg" => "Año:  $anyo Válido <br>"];
    if (!is_numeric($anyo) || $anyo < 1900 || $anyo > 2200) {
        $arrayResultado["valido"] = false;
        $arrayResultado["Msg"] = "Introduce un año desde 1900 al 2200 para el año <br>";
    }
    return $arrayResultado;
}
