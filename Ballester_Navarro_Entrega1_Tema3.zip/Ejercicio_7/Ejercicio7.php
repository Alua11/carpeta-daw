<?php

function rellenar()
{
    $cadenaImg = [];
    $numero = 0;
    for ($i = 0; $i < 25; $i++) {
        for ($j = 0; $j < 4; $j++, $numero++) {
            $cadenaImg[$i][$j] = $numero;
        }
    }
    return $cadenaImg;
}
if (isset($_REQUEST['array'])) {
    $cadeJson = $_REQUEST['array'];
    $cadenaImg = json_decode($cadeJson, JSON_OBJECT_AS_ARRAY);
}
if (!isset($_REQUEST['elegido_x'])) {
    $cadenaImg = rellenar();
} else {
    $imagenPulsada = $_REQUEST['eleccion'];
    $cambio = strpos($imagenPulsada, "x");

    for ($i = 0; $i < 25; $i++) {
        for ($j = 0; $j < 4; $j++) {
            if ($cadenaImg[$i][$j] == $imagenPulsada) {
                if ($cambio === false) {
                    $cadenaImg[$i][$j] .= "x";
                } else {
                    $cadenaImg[$i][$j] = substr($cadenaImg[$i][$j], 0, $cambio);
                }
            }
        }
    }
}
$cadeJson = json_encode($cadenaImg, JSON_OBJECT_AS_ARRAY);

echo "<table>";
for ($i = 0; $i < count($cadenaImg); $i++) {
    echo "<tr>";
    for ($j = 0; $j < count($cadenaImg[$i]); $j++) {
        echo "<td>";
?>
        <form action="Ejercicio7.php" method="post">
            <?php
            if (strpos($cadenaImg[$i][$j], "x") === false) {
            ?>
                <input type="image" name="elegido" id="elegido" value="reserva" src="imagenes/verde.png" height="150" width="150">
            <?php
            } else {
            ?>
                <input type="image" name="elegido" id="elegido" value="reservado" src="imagenes/rojo.png" height="150" width="150">
            <?php
            }
            ?>
            <input type="hidden" name="eleccion" value='<?= $cadenaImg[$i][$j] ?>'>
            <input type="hidden" name="array" value=<?= $cadeJson ?>>
        </form>
<?php
        echo "</td>";
    }
    echo "</tr>";
}
echo "</table>";
