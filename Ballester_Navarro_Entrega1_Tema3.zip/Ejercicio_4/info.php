<?php

$cantidadCalorias = [
    1 => [
        "calorias" => 2
    ],
    2 => [
        "calorias" => 3
    ],
    3 => [
        "calorias" => 3
    ],
    4 => [
        "calorias" => 3
    ],
    5 => [
        "calorias" => 3
    ],
    6 => [
        "calorias" => 3
    ],
    7 => [
        "calorias" => 3
    ],
    8 => [
        "calorias" => 3
    ],
    9 => [
        "calorias" => 3
    ],
    10 => [
        "calorias" => 3
    ],
    11 => [
        "calorias" => 4
    ],
    12 => [
        "calorias" => 4
    ],
    13 => [
        "calorias" => 4
    ],
    14 => [
        "calorias" => 4
    ],
    15 => [
        "calorias" => 4
    ],
    16 => [
        "calorias" => 4
    ],
    17 => [
        "calorias" => 4
    ],
    18 => [
        "calorias" => 4
    ],
    19 => [
        "calorias" => 4
    ],
    20 => [
        "calorias" => 4
    ],
    21 => [
        "calorias" => 5
    ],
    22 => [
        "calorias" => 5
    ],
    23 => [
        "calorias" => 5
    ],
    24 => [
        "calorias" => 5
    ],
    25 => [
        "calorias" => 5
    ],
    26 => [
        "calorias" => 5
    ],
    27 => [
        "calorias" => 5
    ],
    28 => [
        "calorias" => 5
    ],
    29 => [
        "calorias" => 5
    ],
    30 => [
        "calorias" => 5
    ],
    31 => [
        "calorias" => 6
    ],
    32 => [
        "calorias" => 6
    ],
    33 => [
        "calorias" => 6
    ],
    34 => [
        "calorias" => 6
    ],
    35 => [
        "calorias" => 6
    ],
    36 => [
        "calorias" => 6
    ],
    37 => [
        "calorias" => 6
    ],
    38 => [
        "calorias" => 6
    ],
    39 => [
        "calorias" => 6
    ],
    40 => [
        "calorias" => 6
    ],
    41 => [
        "calorias" => 7
    ],
    42 => [
        "calorias" => 7
    ],
    43 => [
        "calorias" => 7
    ],
    44 => [
        "calorias" => 7
    ],
    45 => [
        "calorias" => 7
    ],
    46 => [
        "calorias" => 7
    ],
    47 => [
        "calorias" => 7
    ],
    48 => [
        "calorias" => 7
    ],
    49 => [
        "calorias" => 7
    ],
    50 => [
        "calorias" => 7
    ],
    51 => [
        "calorias" => 8
    ],
    52 => [
        "calorias" => 8
    ],
    53 => [
        "calorias" => 8
    ],
    54 => [
        "calorias" => 8
    ],
    55 => [
        "calorias" => 8
    ],
    56 => [
        "calorias" => 8
    ],
    57 => [
        "calorias" => 8
    ],
    58 => [
        "calorias" => 8
    ],
    59 => [
        "calorias" => 8
    ],
    60 => [
        "calorias" => 8
    ]

];
function ImprimoArray(array $array, array $calorico)
{
    $cadena = "<table>";

    foreach ($array as $indice => $fila) {
        $cadena .= "<tr><td>{$fila}</td></tr>";
    }
    $cadena .= "</table>";
    return $cadena;
}

$array = [];
$cadena = "";
$cadenaFin = "";

$array1 = [];
$arrayCalorias = [];

if (isset($_POST["numero"], $_POST["cadenaJson"])) { //SEGUNDO SIGUIENTES
    // RECOGER DATOS
    $numero = $_POST["numero"];
    $cadenaJson = $_POST["cadenaJson"];
    $array = json_decode($cadenaJson, JSON_OBJECT_AS_ARRAY);
    if ($numero != 0) {
        foreach ($cantidadCalorias as $indice => $calorias) {
            if ($indice <= $numero) {
                $array1[] = $indice;
                $arrayCalorias[] = $calorias["calorias"];
            }
        }
        //DESERIALIZO
        //COMPROBAR DATOS VALIDOS
        //OPERO CON EL ARRAY

        //var_dump($array);
        var_dump($arrayCalorias);
        $cadena = "Has introducido el numero {$numero}";
    } else { //si meto 0 reinicio array
        $cadenaFin = ImprimoArray($array1, $arrayCalorias);
    }
}
$cadenaJson = json_encode($array1);
