//Array en el que se guardaran objetos tipo Coche. 2
const almacen = [];