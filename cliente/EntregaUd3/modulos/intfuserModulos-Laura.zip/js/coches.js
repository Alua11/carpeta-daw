import { etiquetaECO } from "./generarObj.js";
import { guardar, cambiarmat, guardarpush, combustible0aGasolina } from "./funciones.js";
import almacen from "./estructuras.js";
guardar();
cambiarmat();
guardarpush();
etiquetaECO();
// setTipoCombustible();
// mostrarEtECO();
// mostrarCombustible();
// setCambiarTipoCombustible();
combustible0aGasolina();
// mostrarCombustible();

console.log(almacen);