<?php
include_once 'funcionesDigimon.php';
spl_autoload_register('mi_autoloader');

/*
$d = new Digimon('Agumon', '30', '10', 'elemental', '1');
$d = new Digimon('Greymon', '50', '30', 'elemental', '2');
$d = new Digimon('Metalgreymon', '90', '70', 'elemental', '3');
$d = new Digimon('Gabumon', '20', '20', 'animal', '1');
$d = new Digimon('Garurumon', '40', '40', 'animal', '2');
$d = new Digimon('Weregarurumon', '80', '80', 'animal', '3');
$d = new Digimon('Palmon', '20', '20', 'planta', '1');
$d = new Digimon('Togemon', '50', '30', 'planta', '2');
$d = new Digimon('Lilimon', '120', '40', 'planta', '3');
$d = new Digimon('Tentomon', '10', '30', 'virus', '1');
$d = new Digimon('Kabuterimon', '30', '50', 'virus', '2');
$d = new Digimon('Megakabuterimon', '70', '90', 'virus', '3');
$d = new Digimon('Piyomon', '30', '10', 'animal', '1');
$d = new Digimon('Birdramon', '50', '30', 'animal', '2');
$d = new Digimon('Angemon', '40', '40', 'vacuna', '2');
$d = new Digimon('Gatomon', '20', '20', 'vacuna', '1');
$d = new Digimon('Nefertimon', '40', '40', 'vacuna', '2');
$d = new Digimon('Salamon', '10', '10', 'vacuna', '1');
$d = new Digimon('Shakkoumon', '80', '80', 'vacuna', '3');
$d = new Digimon('Submarimon', '60', '20', 'animal', '2');
$d = new Digimon('Armadillon', '10', '30', 'elemental', '1');
$d = new Digimon('Ankylomon', '20', '60', 'elemental', '2');
$d = new Digimon('Digmon', '20', '20', 'elemental', '1');
$d = new Digimon('Garudamon', '120', '40', 'animal', '3');
*/

$j = new Juego();
// $d1 = $j->getDigimons()['agumon'];

// $j->enfrentamiento($d1, $d1);

// $j->pedirDigievolucion();

// $j->crearUsu();

// echo $j;

// $j->mostrarTodosDigimons();

