<?php
class Juego extends Producto {
    
        
}