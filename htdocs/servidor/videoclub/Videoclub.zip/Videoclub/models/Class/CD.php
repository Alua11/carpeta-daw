<?php
class CD extends Producto {
    
        
}