<?php
class Pelicula extends Producto {
    
        
}